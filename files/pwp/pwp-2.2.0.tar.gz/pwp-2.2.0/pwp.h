/*
 * Copyright (c) 2015, 2016 Steven Roberts <sroberts@fenderq.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include <sys/param.h>
#include <sys/queue.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <assert.h>
#include <ctype.h>
#include <db.h>
#include <err.h>
#include <fcntl.h>
#include <limits.h>
#include <math.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <readpassphrase.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <util.h>
#include <zlib.h>

#define DEFAULT_ENTROPY 128
#define MAX_STRING 256

#define PD_ARCHIVED 0x0001

#define VER_MAJ 2
#define VER_MIN 2
#define VER_REV 0

enum mode {
	M_UNDEFINED,
	M_ALNUM,
	M_ALPHA,
	M_BASE58,
	M_DICEWARE,
	M_DIGIT,
	M_GRAPH,
	M_LOWER,
	M_UPPER,
	M_XDIGIT
};

enum dump {
	DUMP_UNDEFINED,
	DUMP_ALL,
	DUMP_NAMES,
	DUMP_RECORD,
	DUMP_INVALID
};

struct cipher_data {
	int enc;
	void *key;
	void *iv;
	void *in;
	size_t inl;
	void *out;
	size_t outl;
};

struct digest_data {
	void *in;
	size_t inl;
	unsigned char out[EVP_MAX_MD_SIZE];
	unsigned int outl;
};

struct pass_data {
	char passwd[MAX_STRING];
	char name[MAX_STRING];
	int num;
	short flags;
	time_t created;
	char prev[MAX_STRING];
};

struct genpw {
	char fname[PATH_MAX];
	char pw[MAX_STRING];
	double entropy;
	enum mode mode;
	int enforce;
	unsigned int length;
};

char		*diceware(int, char *, size_t);

int		 do_password(struct genpw *);
enum mode	 getopt_mode(const char *);
int		 randstr(const char *, char *, size_t);

void		 database_close(void);
int		 database_open(int);
enum dump	 getopt_dump(const char *);
int		 rec_dump(int);
int		 rec_dump_name(const char *);
int		 rec_read(const char *, struct pass_data *);
int		 rec_write(const char *, struct pass_data *);

int		 do_cipher(struct cipher_data *);
int		 do_digest(struct digest_data *);
int		 do_hmac(struct digest_data *, unsigned char *, int);
void		 kdf(uint8_t *, size_t, int, int, int, uint8_t *, size_t);
int		 regress(void);

extern char *__progname;
extern const int dwnum;
extern int verbose;
