/*
 * Copyright (c) 2014-2016 Steven Roberts <sroberts@fenderq.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "pwp.h"

#define MAX_ENFORCE_RETRY 100
#define MAX_LINE 4096

#define UPPER "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#define LOWER "abcdefghijklmnopqrstuvwxyz"
#define DIGIT "0123456789"
#define SYMBOLS "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
#define HEX "ABCDEF"

#define B58_UPPER "ABCDEFGHJKLMNPQRSTUVWXYZ"
#define B58_LOWER "abcdefghijkmnopqrstuvwxyz"
#define B58_DIGIT "123456789"

struct entry {
	SLIST_ENTRY(entry) entries;
	char *data;
	size_t size;
};
SLIST_HEAD(entry_head, entry);

static char	*charset_create(struct entry_head *);
static int	 contains_entry(char *, struct entry *);
static int	 validate(struct entry_head *, char *);

static int	 entries_add(struct entry_head *, char *);
static int	 entries_free(struct entry_head *);
static int	 entries_generate(struct entry_head *, enum mode);
static int	 entries_load(struct entry_head *, char *);

static double	 entropy_bits(int, int);
static int	 entropy_len(int, double);
static int	 entropy_set(int, double *, unsigned int *);

int
do_password(struct genpw *gpw)
{
	char *cs;
	int retries;
	size_t cslen;
	struct entry_head head;

	SLIST_INIT(&head);

	if (gpw->mode == M_DICEWARE) {
		entropy_set(dwnum, &gpw->entropy, &gpw->length);
		diceware(gpw->length, gpw->pw, sizeof(gpw->pw));
		return 0;
	}

	if (gpw->fname[0] != '\0')
		entries_load(&head, gpw->fname);
	else
		entries_generate(&head, gpw->mode);

	cs = charset_create(&head);
	cslen = strlen(cs);
	entropy_set(cslen, &gpw->entropy, &gpw->length);
	if (gpw->length >= sizeof(gpw->pw)) {
		errx(1, "password truncation: %ld bytes",
		    gpw->length - sizeof(gpw->pw) + 1);
	}

	retries = 0;
	do {
		randstr(cs, gpw->pw, gpw->length + 1);
		if (gpw->enforce == 0)
			break;
		if (validate(&head, gpw->pw))
			break;
		retries++;
		if (retries >= MAX_ENFORCE_RETRY) {
			errx(1, "enforce retry limit (%d) reached", retries);
			break;
		}
	} while (1);

	if (verbose && retries > 0)
		printf("enforce retries = %d\n", retries);

	free(cs);
	entries_free(&head);

	return 0;
}

enum mode
getopt_mode(const char *s)
{
	enum mode mode;

	mode = M_UNDEFINED;

	if (strcmp(s, "alnum") == 0)
		mode = M_ALNUM;
	else if (strcmp(s, "alpha") == 0)
		mode = M_ALPHA;
	else if (strcmp(s, "base58") == 0)
		mode = M_BASE58;
	else if (strcmp(s, "diceware") == 0)
		mode = M_DICEWARE;
	else if (strcmp(s, "digit") == 0)
		mode = M_DIGIT;
	else if (strcmp(s, "graph") == 0)
		mode = M_GRAPH;
	else if (strcmp(s, "lower") == 0)
		mode = M_LOWER;
	else if (strcmp(s, "upper") == 0)
		mode = M_UPPER;
	else if (strcmp(s, "xdigit") == 0)
		mode = M_XDIGIT;
	else
		errx(1, "invalid mode: %s", s);

	return mode;
}

int
randstr(const char *charset, char *str, size_t size)
{
	char ch;
	int i;
	int n;
	int len;
	int upper_bound;

	len = size - 1;
	upper_bound = strlen(charset);
	for (i = 0; i < len; i++) {
		n = arc4random_uniform(upper_bound);
		ch = charset[n];
		str[i] = ch;
	}
	str[len] = '\0';

	return 0;
}

static char *
charset_create(struct entry_head *head)
{
	char *charset;
	char *p;
	size_t size;
	struct entry *np;

	size = 0;
	charset = NULL;

	SLIST_FOREACH(np, head, entries) {
		size += charset ? np->size - 1 : np->size;
		if ((p = realloc(charset, size)) == NULL)
			err(1, "realloc");
		if (charset == NULL && size > 0)
			p[0] = '\0';
		charset = p;
		strlcat(charset, np->data, size);
	}

	if (verbose)
		printf("charset = %s\n", charset);

	return charset;
}

static int
contains_entry(char *str, struct entry *np)
{
	char ch;
	int i;
	int j;
	int nlen;
	int slen;

	slen = strlen(str);
	nlen = strlen(np->data);
	for (i = 0; i < slen; i++) {
		ch = str[i];
		for (j = 0; j < nlen; j++) {
			if (ch == np->data[j])
				return 1;
		}
	}

	return 0;
}

static int
entries_add(struct entry_head *head, char *e)
{
	int len;
	struct entry *n1;

	len = strlen(e);
	if (len == 0)
		return 1;

	if ((n1 = malloc(sizeof(struct entry))) == NULL)
		err(1, "malloc");
	n1->size = len + 1;
	if ((n1->data = malloc(n1->size)) == NULL)
		err(1, "malloc");
	strlcpy(n1->data, e, n1->size);
	SLIST_INSERT_HEAD(head, n1, entries);

	if (verbose)
		printf("added entry: %s\n", n1->data);

	return 0;
}

static int
entries_free(struct entry_head *head)
{
	struct entry *n1;

	while (!SLIST_EMPTY(head)) {
		n1 = SLIST_FIRST(head);
		SLIST_REMOVE_HEAD(head, entries);
		free(n1->data);
		free(n1);
	}

	return 0;
}

static int
entries_generate(struct entry_head *head, enum mode mode)
{
	switch (mode) {
	case M_ALNUM:
		entries_add(head, DIGIT);
		entries_add(head, LOWER);
		entries_add(head, UPPER);
		break;
	case M_ALPHA:
		entries_add(head, LOWER);
		entries_add(head, UPPER);
		break;
	case M_BASE58:
		entries_add(head, B58_DIGIT);
		entries_add(head, B58_LOWER);
		entries_add(head, B58_UPPER);
		break;
	case M_DIGIT:
		entries_add(head, DIGIT);
		break;
	case M_GRAPH:
		entries_add(head, SYMBOLS);
		entries_add(head, DIGIT);
		entries_add(head, LOWER);
		entries_add(head, UPPER);
		break;
	case M_LOWER:
		entries_add(head, LOWER);
		break;
	case M_UPPER:
		entries_add(head, UPPER);
		break;
	case M_XDIGIT:
		entries_add(head, HEX);
		entries_add(head, DIGIT);
		break;
	default:
		errx(1, "invalid mode: %d", mode);
		break;
	}

	return 0;
}

static int
entries_load(struct entry_head *head, char *fname)
{
	FILE *fp;
	char *newline;
	char line[MAX_LINE];
	int added;

	added = 0;

	if ((fp = fopen(fname, "r")) == NULL)
		err(1, fname);

	while (fgets(line, sizeof(line), fp)) {
		if ((newline = strrchr(line, '\n')) != NULL)
			*newline = '\0';
		if (entries_add(head, line) == 0)
			added++;
	}

	if (ferror(fp))
		err(1, fname);
	if (added == 0)
		errx(1, "no entries: %s", fname);

	fclose(fp);

	if (verbose)
		printf("%d entries added from %s\n", added, fname);

	return 0;
}

static double
entropy_bits(int symbols, int len)
{
	double bits;
	double x;

	x = pow(symbols, len);
	bits = log2(x);

	return bits;
}

static int
entropy_len(int symbols, double bits)
{
	double x;
	int len;

	x = bits / log2(symbols);
	len = ceil(x);

	return len;
}

static int
entropy_set(int symbols, double *bits, unsigned int *len)
{
	double eps;

	/* It is invalid to specify both bits and len. */
	assert(!(*bits && *len));

	eps = log2(symbols);
	if (eps < 1)
		errx(1, "not enough entropy per symbol: %.3f bits", eps);

	/* When bits is specified, calculate length (rounded up). */
	if (*bits)
		*len = entropy_len(symbols, *bits);

	/* Update bits to precisely reflect length used. */
	*bits = entropy_bits(symbols, *len);

	if (verbose) {
		printf("symbols: %d\n"
		    "entropy per symbol: %.3f bits\n"
		    "entropy: %.3f bits\n"
		    "length: %u\n",
		    symbols, eps, *bits, *len);
	}

	return 0;
}

static int
validate(struct entry_head *head, char *str)
{
	struct entry *np;

	SLIST_FOREACH(np, head, entries) {
		if (contains_entry(str, np) == 0)
			return 0;
	}

	return 1;
}
