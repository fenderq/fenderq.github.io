/*
 * Copyright (c) 2015, 2016 Steven Roberts <sroberts@fenderq.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "pwp.h"

#define MASTER_KEY_ID "Or fher gb qevax lbhe Binygvar"
#define MAX_TIME_STR 64
#define ROUNDS 42
#define SALT_SIZE 16
#define UID_SIZE 32

struct master_key {
	struct key_data {
		unsigned char enckey[EVP_MAX_KEY_LENGTH];
		unsigned char hmackey[EVP_MAX_KEY_LENGTH];
	} kd;
	unsigned char md[EVP_MAX_MD_SIZE];
	unsigned char salt[SALT_SIZE];
	struct version {
		short maj;
		short min;
		short rev;
	} v;
};

DB *db;
DBT dbd;
DBT dbk;
HASHINFO hashinfo;
struct master_key mk;

static int	 backup_database(const char *);
static int	 gzip_file(const char *, const char *);
static int	 mk_create(void);
static int	 mk_load(void);
static int	 rec_decrypt(struct pass_data *, void *, size_t);
static int	 rec_encrypt(struct pass_data *, void **, size_t *);
static void	 rec_print(struct pass_data *);
static int	 rec_save(struct pass_data *);
static int	 rec_set_prev(struct pass_data *);
static void	 hmac_str(const char *, struct digest_data *);
static char	*str_time(char *, size_t, time_t);

void
database_close(void)
{
	explicit_bzero(&mk, sizeof(mk));
	if (db) {
		if (verbose)
			printf("closing database\n");
		db->close(db);
		db = NULL;
	}
}

int
database_open(int rdrw)
{
	char dbfile[PATH_MAX];
	char dir[PATH_MAX];
	const char *homedir;
	int create;
	int flags;
	struct stat sb;

	if ((homedir = getenv("HOME")) == NULL)
		errx(1, "HOME directory undefined");

	create = 0;
	flags = O_EXLOCK;
	snprintf(dir, sizeof(dir), "%s/.%s", homedir, __progname);
	snprintf(dbfile, sizeof(dbfile), "%s/%s.db", dir, __progname);
	if (stat(dbfile, &sb) != 0) {
		if (errno == ENOENT) {
			if (mkdir(dir, 0700) != 0)
				err(1, "mkdir");
			create = 1;
			flags |= O_CREAT;
			if (verbose)
				printf("creating db file %s\n", dbfile);
		} else
			err(1, "%s", dbfile);
	} else if (rdrw != 0)
		backup_database(dbfile);

	flags |= (create == 0 && rdrw == 0) ? O_RDONLY : O_RDWR;

	if (verbose)
		printf("opening database, mode (%d)\n", flags);

	memset(&hashinfo, 0, sizeof(hashinfo));
	if ((db = dbopen(dbfile, flags, 0600, DB_HASH, &hashinfo)) == NULL)
		err(1, "dbopen: %s", dbfile);

	if (create == 1)
		mk_create();
	else
		mk_load();

	return 0;
}

enum dump
getopt_dump(const char *s)
{
	enum dump dump;

	if (strcmp(s, "all") == 0)
		dump = DUMP_ALL;
	else if (strcmp(s, "names") == 0)
		dump = DUMP_NAMES;
	else if (strcmp(s, "rec") == 0)
		dump = DUMP_RECORD;
	else
		dump = DUMP_INVALID;

	return dump;
}

int
rec_dump(int mode)
{
	int s;
	struct pass_data pd;

	for (s = db->seq(db, &dbk, &dbd, R_FIRST); s == 0;
	    s = db->seq(db, &dbk, &dbd, R_NEXT)) {
		/* skip master key record */
		if (memcmp(dbk.data, MASTER_KEY_ID, dbk.size) == 0)
			continue;
		rec_decrypt(&pd, dbd.data, dbd.size);
		/* dump all or names */
		if (mode == 0)
			rec_print(&pd);
		else if (!(pd.flags & PD_ARCHIVED))
			printf("%s\t%s\n", pd.name, pd.passwd);
	}

	explicit_bzero(&pd, sizeof(pd));

	if (s == -1)
		err(1, "db->seq");

	return 0;
}

int
rec_dump_name(const char *name)
{
	char t[MAX_TIME_STR];
	struct pass_data pd;

	if (rec_read(name, &pd) == 0) {
		if (pd.prev != '\0')
			rec_dump_name(pd.prev);
		str_time(t, sizeof(t), pd.created);
		printf("%s %05d %s\n", t, pd.num, pd.passwd);
		explicit_bzero(&pd, sizeof(pd));
	}

	return 0;
}

int
rec_read(const char *name, struct pass_data *pd)
{
	int s;
	struct digest_data hmac;

	hmac_str(name, &hmac);
	dbk.data = hmac.out;
	dbk.size = hmac.outl;

	s = db->get(db, &dbk, &dbd, 0);
	if (s == 0) {
		rec_decrypt(pd, dbd.data, dbd.size);
		if (strcmp(pd->name, name) != 0)
			errx(1, "key/data name mismatch");
	} else if (s == -1)
		err(1, "db->get");

	explicit_bzero(&hmac, sizeof(hmac));

	return s;
}

int
rec_write(const char *name, struct pass_data *curr)
{
	struct pass_data prev;

	curr->num = 1;
	time(&curr->created);
	if (rec_read(name, &prev) == 0) {
		rec_set_prev(curr);
		curr->num = prev.num + 1;
		rec_save(curr);
		strlcpy(prev.name, curr->prev, sizeof(prev.name));
		prev.flags |= PD_ARCHIVED;
		rec_save(&prev);
		explicit_bzero(&prev, sizeof(prev));
	} else
		rec_save(curr);

	return 0;
}

static int
backup_database(const char *dbfile)
{
	char bakfile[PATH_MAX];
	char tmp[PATH_MAX];
	int i;

	for (i = 2; i > 0; i--) {
		snprintf(tmp, sizeof(tmp), "%s.%d.gz", dbfile, i);
		snprintf(bakfile, sizeof(bakfile), "%s.%d.gz", dbfile, i - 1);
		if (rename(bakfile, tmp) == -1 && errno != ENOENT)
			err(1, "%s -> %s", bakfile, tmp);
	}
	gzip_file(dbfile, bakfile);

	return 0;
}

static int
gzip_file(const char *infile, const char *outfile)
{
	gzFile gz;
	int flags;
	int in;
	int out;
	ssize_t rcount;
	ssize_t wcount;
	unsigned char *buf;

	if ((buf = malloc(MAXBSIZE)) == NULL)
		err(1, "malloc");

	flags = O_RDONLY | O_EXLOCK;
	if ((in = open(infile, flags)) == -1)
		err(1, "%s", infile);

	flags = O_CREAT | O_TRUNC | O_EXLOCK | O_WRONLY;
	if ((out = open(outfile, flags, 0600)) == -1)
		err(1, "%s", outfile);
	if ((gz = gzdopen(out, "wb")) == NULL)
		errx(1, "gzdopen returned NULL on %d: %s", out, outfile);

	while ((rcount = read(in, buf, sizeof(buf))) > 0) {
		wcount = gzwrite(gz, buf, rcount);
		if (wcount != rcount || wcount == 0)
			errx(1, "gzwrite error: %s", outfile);
	}
	if (rcount < 0)
		err(1, "%s", infile);

	if (close(in) == -1)
		err(1, "%s", infile);
	gzclose(gz);

	free(buf);

	return 0;
}

static int
mk_create(void)
{
	int s;
	size_t i;
	struct digest_data digest;
	struct key_data kd;
	unsigned char *p;
	unsigned char xorkey[sizeof(mk.kd)];

	if (verbose)
		printf("creating master key\n");

	arc4random_buf(&mk, sizeof(mk));

	mk.v.maj = VER_MAJ;
	mk.v.min = VER_MIN;
	mk.v.rev = VER_REV;

	digest.in = &mk.kd;
	digest.inl = sizeof(mk.kd);
	do_digest(&digest);
	memcpy(mk.md, digest.out, digest.outl);

	kd = mk.kd;
	p = (void *)&mk.kd;
	kdf(mk.salt, sizeof(mk.salt), ROUNDS, 1, 1, xorkey, sizeof(xorkey));
	for (i = 0; i < sizeof(mk.kd); i++)
		p[i] ^= xorkey[i];
	explicit_bzero(&xorkey, sizeof(xorkey));

	dbk.data = MASTER_KEY_ID;
	dbk.size = strlen(MASTER_KEY_ID);
	dbd.data = &mk;
	dbd.size = sizeof(mk);

	if (verbose)
		printf("storing master key in db\n");

	if ((s = db->put(db, &dbk, &dbd, R_NOOVERWRITE)) == -1)
		err(1, "db->put");
	else if (s == 1)
		errx(1, "master key record already exists");

	if (db->sync(db, 0) == -1)
		err(1, "db->sync");

	mk.kd = kd;
	explicit_bzero(&kd, sizeof(kd));

	return 0;
}

static int
mk_load(void)
{
	int s;
	size_t i;
	struct digest_data digest;
	unsigned char *p;
	unsigned char xorkey[sizeof(mk.kd)];

	if (verbose)
		printf("loading master key\n");

	dbk.data = MASTER_KEY_ID;
	dbk.size = strlen(MASTER_KEY_ID);
	s = db->get(db, &dbk, &dbd, 0);
	if (s == -1)
		err(1, "db->get");
	else if (s == 1)
		errx(1, "master key not found");

	memcpy(&mk, dbd.data, sizeof(mk));

	p = (void *)&mk.kd;
	kdf(mk.salt, sizeof(mk.salt), ROUNDS, 1, 0, xorkey, sizeof(xorkey));
	for (i = 0; i < sizeof(mk.kd); i++)
		p[i] ^= xorkey[i];
	explicit_bzero(&xorkey, sizeof(xorkey));

	digest.in = &mk.kd;
	digest.inl = sizeof(mk.kd);
	do_digest(&digest);
	if (memcmp(&mk.md, digest.out, digest.outl) != 0)
		errx(1, "incorrect passphrase");

	if (mk.v.maj != VER_MAJ || mk.v.min != VER_MIN)
		errx(1, "unsupported database v%d.%d.%d",
		    mk.v.maj, mk.v.min, mk.v.rev);

	return 0;
}

static int
rec_decrypt(struct pass_data *pd, void *data, size_t size)
{
	size_t min;
	size_t psize;
	struct cipher_data cipher;
	struct digest_data hmac;
	unsigned char *iv;
	unsigned char *p;

	/* validate size */
	min = sizeof(hmac.out) + EVP_MAX_IV_LENGTH;
	if (size <= min)
		errx(1, "decrypt: invalid data size %ld", size);

	/* hmac data */
	p = data;
	psize = size;
	p += sizeof(hmac.out);
	psize -= sizeof(hmac.out);
	hmac.in = p;
	hmac.inl = psize;
	do_hmac(&hmac, mk.kd.hmackey, sizeof(mk.kd.hmackey));
	if (memcmp(hmac.out, data, hmac.outl) != 0)
		errx(1, "decrypt: hmac validation failure");

	/* decrypt data */
	iv = p;
	p += EVP_MAX_IV_LENGTH;
	psize -= EVP_MAX_IV_LENGTH;
	cipher.in = p;
	cipher.inl = psize;
	cipher.key = mk.kd.enckey;
	cipher.iv = iv;
	cipher.enc = 0;
	do_cipher(&cipher);

	/* skip random pad */
	p = cipher.out;
	psize = cipher.outl;
	p += EVP_MAX_BLOCK_LENGTH;
	psize -= EVP_MAX_BLOCK_LENGTH;

	/* return pass_data */
	if (psize != sizeof(struct pass_data))
		errx(1, "decrypt: data has invalid record size %ld", psize);
	memcpy(pd, p, sizeof(struct pass_data));

	explicit_bzero(cipher.out, cipher.outl);
	free(cipher.out);

	return 0;
}

static int
rec_encrypt(struct pass_data *pd, void **enc_data, size_t *enc_size)
{
	size_t size;
	struct cipher_data cipher;
	struct digest_data hmac;
	unsigned char *p;
	unsigned char iv[EVP_MAX_IV_LENGTH];
	void *data;

	/* ciphertext = random pad + pass_data */
	size = EVP_MAX_BLOCK_LENGTH + sizeof(struct pass_data);
	if ((data = malloc(size)) == NULL)
		err(1, "malloc");
	p = data;
	arc4random_buf(p, EVP_MAX_BLOCK_LENGTH);
	p += EVP_MAX_BLOCK_LENGTH;
	memcpy(p, pd, sizeof(struct pass_data));
	cipher.enc = 1;
	cipher.in = data;
	cipher.inl = size;
	cipher.key = mk.kd.enckey;
	arc4random_buf(iv, sizeof(iv));
	cipher.iv = iv;
	do_cipher(&cipher);
	explicit_bzero(data, size);

	/* hmac = iv + ciphertext */
	size = sizeof(iv) + cipher.outl;
	if ((p = realloc(data, size)) == NULL)
		err(1, "realloc");
	data = p;
	memcpy(p, iv, sizeof(iv));
	p += sizeof(iv);
	memcpy(p, cipher.out, cipher.outl);
	hmac.in = data;
	hmac.inl = size;
	do_hmac(&hmac, mk.kd.hmackey, sizeof(mk.kd.hmackey));

	/* enc_data = hmac + iv + ciphertext */
	size += sizeof(hmac.out);
	if ((p = realloc(data, size)) == NULL)
		err(1, "realloc");
	data = p;
	memcpy(p, hmac.out, sizeof(hmac.out));
	p += sizeof(hmac.out);
	memcpy(p, iv, sizeof(iv));
	p += sizeof(iv);
	memcpy(p, cipher.out, cipher.outl);
	free(cipher.out);

	*enc_data = data;
	*enc_size = size;

	return 0;
}

static void
rec_print(struct pass_data *pd)
{
	char created[MAX_TIME_STR];

	str_time(created, sizeof(created), pd->created);
	printf("name: %s\n"
	    "password: %s\n"
	    "created: %s\n"
	    "archived: %s\n"
	    "number: %d\n"
	    "previous: %s\n",
	    pd->name,
	    pd->passwd,
	    created,
	    pd->flags & PD_ARCHIVED ? "true" : "false",
	    pd->num,
	    pd->prev);
}

static int
rec_save(struct pass_data *pd)
{
	int s;
	size_t enc_size;
	struct digest_data hmac;
	void *enc_data;

	hmac_str(pd->name, &hmac);
	dbk.data = hmac.out;
	dbk.size = hmac.outl;

	rec_encrypt(pd, &enc_data, &enc_size);
	dbd.data = enc_data;
	dbd.size = enc_size;

	if ((s = db->put(db, &dbk, &dbd, 0)) == -1)
		err(1, "db->put");
	else if (s == 1)
		warnx("R_NOOVERWRITE %s", pd->name);

	if (db->sync(db, 0) == -1)
		err(1, "db->sync");

	free(enc_data);

	return 0;
}

static int
rec_set_prev(struct pass_data *pd)
{
	char uid[UID_SIZE];
	const char *charset = "ABCDEF0123456789";
	int s;
	struct digest_data hmac;

	do {
		/* generate a uid until we find one that does not exist */
		randstr(charset, uid, sizeof(uid));
		snprintf(pd->prev, sizeof(pd->prev), "%s (%s)", pd->name, uid);
		hmac_str(pd->prev, &hmac);
		dbk.data = hmac.out;
		dbk.size = hmac.outl;
		if ((s = db->get(db, &dbk, &dbd, 0)) == -1)
			err(1, "db->get");
	} while (s == 0);

	if (verbose)
		printf("setting previous uid: %s\n", pd->prev);

	explicit_bzero(&uid, sizeof(uid));

	return 0;
}

static void
hmac_str(const char *str, struct digest_data *hmac)
{
	hmac->in = (void *)str;
	hmac->inl = strlen(str);
	do_hmac(hmac, mk.kd.hmackey, sizeof(mk.kd.hmackey));
}

static char *
str_time(char *str, size_t size, time_t t)
{
	struct tm tm;

	localtime_r(&t, &tm);
	if (strftime(str, size, "%Y-%m-%dT%H:%M:%S", &tm) == 0)
		errx(1, "strftime truncation");

	return str;
}
