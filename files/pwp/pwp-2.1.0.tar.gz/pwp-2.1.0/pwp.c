/*
 * Copyright (c) 2015, 2016 Steven Roberts <sroberts@fenderq.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "pwp.h"

#define OPT_NEW_PW 0x0001

#define MIN_ENTROPY 32
#define MAX_ENTROPY 512
#define MIN_LENGTH 1
#define MAX_LENGTH MAX_STRING - 1

enum cmd {
	CMD_UNDEFINED,
	CMD_DUMP_ALL,
	CMD_DUMP_RECORD,
	CMD_DUMP_NAMES,
	CMD_GENPW,
	CMD_NEW_PW,
	CMD_PRINT_PW
};

int verbose;

__dead void usage(void);

static enum cmd get_cmd(int, struct genpw *, struct pass_data *, enum dump);

int
main(int argc, char *argv[])
{
	char ch;
	const char *errstr;
	enum cmd cmd;
	enum dump dump;
	int opts;
	struct genpw gpw;
	struct pass_data pd;

	if (pledge("stdio rpath wpath cpath flock tty", NULL) == -1)
		err(1, "pledge");

	arc4random_buf(&pd, sizeof(pd));
	pd.name[0] = '\0';
	pd.passwd[0] = '\0';
	pd.prev[0] = '\0';
	pd.flags = 0;
	memset(&gpw, 0, sizeof(gpw));
	dump = DUMP_UNDEFINED;
	opts = 0;

	atexit(close_database);

	ERR_load_crypto_strings();
	OpenSSL_add_all_algorithms();

#if 0
	regress();
	exit(0);
#endif

	while ((ch = getopt(argc, argv, "b:d:ef:hl:m:np:v")) != -1) {
		switch (ch) {
		case 'b':
			gpw.entropy = strtonum(optarg, MIN_ENTROPY,
			    MAX_ENTROPY, &errstr);
			if (errstr != NULL)
				errx(1, "bits %s", errstr);
			break;
		case 'd':
			dump = getopt_dump(optarg);
			break;
		case 'e':
			gpw.enforce = 1;
			break;
		case 'f':
			strlcpy(gpw.fname, optarg, sizeof(gpw.fname));
			break;
		case 'l':
			gpw.length = strtonum(optarg, MIN_LENGTH,
			    MAX_LENGTH, &errstr);
			if (errstr != NULL)
				errx(1, "length %s", errstr);
			break;
		case 'm':
			gpw.mode = getopt_mode(optarg);
			break;
		case 'n':
			opts |= OPT_NEW_PW;
			break;
		case 'p':
			strlcpy(pd.passwd, optarg, sizeof(pd.passwd));
			break;
		case 'v':
			verbose = 1;
			break;
		case 'h':
			/* FALLTHROUGH */
		default:
			usage();
			/* NOTREACHED */
		}
	}
	argc -= optind;
	argv += optind;

	if (argc == 1)
		strlcpy(pd.name, argv[0], sizeof(pd.name));
	else if (argc > 1)
		usage();

	if (verbose)
		printf("%s v%d.%d.%d\n", __progname,
		    VER_MAJ, VER_MIN, VER_REV);

	if ((cmd = get_cmd(opts, &gpw, &pd, dump)) == CMD_UNDEFINED)
		usage();

	if (cmd != CMD_GENPW)
		open_database(opts & OPT_NEW_PW);

	if (pledge("stdio rpath", NULL) == -1)
		err(1, "pledge");

	switch (cmd) {
	case CMD_DUMP_ALL:
		rec_dump(0);
		break;
	case CMD_DUMP_NAMES:
		rec_dump(1);
		break;
	case CMD_DUMP_RECORD:
		rec_dump_name(pd.name);
		break;
	case CMD_GENPW:
		do_password(&gpw);
		printf("%s\n", gpw.pw);
		break;
	case CMD_NEW_PW:
		if (pd.passwd[0] == '\0') {
			do_password(&gpw);
			strlcpy(pd.passwd, gpw.pw, sizeof(pd.name));
		}
		rec_write(pd.name, &pd);
		printf("%s\n", pd.passwd);
		break;
	case CMD_PRINT_PW:
		if (rec_read(pd.name, &pd) == 0)
			printf("%s\n", pd.passwd);
		else
			warnx("record not found: %s", pd.name);
		break;
	default:
		warnx("command undefined");
		break;
	}

	EVP_cleanup();
	ERR_free_strings();

	exit(EXIT_SUCCESS);
}

void
usage(void)
{
	fprintf(stderr, "usage: %s [-ehnv] ", __progname);
	fprintf(stderr, "[-b bits | -l length] [ -f filename | -m mode]\n");
	fprintf(stderr, "\t[-p password] [-d all | names | rec] record\n");

	exit(EXIT_FAILURE);
}

static enum cmd
get_cmd(int opts, struct genpw *gpw, struct pass_data *pd, enum dump dump)
{
	enum cmd cmd;

	cmd = CMD_GENPW;

	/* prevent invalid combinations */
	if (gpw->entropy != 0 && gpw->length != 0)
		return CMD_UNDEFINED;
	if (gpw->fname[0] != '\0' && gpw->mode != M_UNDEFINED)
		return CMD_UNDEFINED;

	/* defaults for password generation */
	if (gpw->entropy == 0 && gpw->length == 0)
		gpw->entropy = DEFAULT_ENTROPY;
	if (gpw->fname[0] == '\0' && gpw->mode == M_UNDEFINED)
		gpw->mode = M_BASE58;

	if (dump != DUMP_UNDEFINED) {
		if (dump == DUMP_ALL)
			return CMD_DUMP_ALL;
		else if (dump == DUMP_NAMES)
			return CMD_DUMP_NAMES;
		else if (dump == DUMP_RECORD) {
			if (pd->name[0] != '\0')
				return CMD_DUMP_RECORD;
		}
		return CMD_UNDEFINED;
	}

	if (pd->name[0] != '\0') {
		if (opts & OPT_NEW_PW)
			return CMD_NEW_PW;
		else
			return CMD_PRINT_PW;
	}

	return cmd;
}
