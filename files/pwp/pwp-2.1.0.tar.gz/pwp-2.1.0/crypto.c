/*
 * Copyright (c) 2015, 2016 Steven Roberts <sroberts@fenderq.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#include "pwp.h"

#define BUF_SIZE MAXBSIZE
#define DEFAULT_CIPHER "AES-256-CBC"
#define DEFAULT_DIGEST "SHA512"
#define REGRESS_DATA_SIZE 1024 * 1024

static int add_cipher_data(struct cipher_data *, void *, size_t);
static void crypto_error(void);

int
do_cipher(struct cipher_data *cipher)
{
	EVP_CIPHER_CTX ctx;
	const EVP_CIPHER *type;
	const char *mode;
	int psize;
	int rem;
	int written;
	unsigned char *p;
	unsigned char buf[BUF_SIZE + EVP_MAX_BLOCK_LENGTH];

	cipher->out = NULL;
	cipher->outl = 0;

	mode = cipher->enc == 1 ? "encrypt" : "decrypt";
	if (verbose)
		printf("%s(%s) ", mode, DEFAULT_CIPHER);

	type = EVP_get_cipherbyname(DEFAULT_CIPHER);
	assert(type != NULL);
	EVP_CIPHER_CTX_init(&ctx);
	if (EVP_CipherInit_ex(&ctx, type, NULL, cipher->key,
	    cipher->iv, cipher->enc) != 1)
		crypto_error();
	p = cipher->in;
	rem = cipher->inl;
	while (rem > 0) {
		psize = rem > BUF_SIZE ? BUF_SIZE : rem;
		if (EVP_CipherUpdate(&ctx, buf, &written, p, psize) != 1)
			crypto_error();
		rem -= psize;
		p += psize;
		add_cipher_data(cipher, buf, written);
	}
	if (EVP_CipherFinal_ex(&ctx, buf, &written) != 1)
		crypto_error();
	add_cipher_data(cipher, buf, written);
	if (EVP_CIPHER_CTX_cleanup(&ctx) != 1)
		crypto_error();

	explicit_bzero(buf, sizeof(buf));

	if (verbose) {
		printf("%ld bytes in, %ld bytes out\n",
		    cipher->inl, cipher->outl);
	}

	return 0;
}

int
do_digest(struct digest_data *digest)
{
	EVP_MD_CTX ctx;
	const EVP_MD *type;
	int i;
	int psize;
	int rem;
	unsigned char *p;

	if (verbose)
		printf("digest(%s) = ", DEFAULT_DIGEST);

	arc4random_buf(digest->out, sizeof(digest->out));
	digest->outl = 0;

	EVP_MD_CTX_init(&ctx);
	type = EVP_get_digestbyname(DEFAULT_DIGEST);
	assert(type != NULL);
	if (EVP_DigestInit_ex(&ctx, type, NULL) != 1)
		crypto_error();
	p = digest->in;
	rem = digest->inl;
	while (rem > 0) {
		psize = rem > BUF_SIZE ? BUF_SIZE : rem;
		if (EVP_DigestUpdate(&ctx, p, psize) != 1)
			crypto_error();
		rem -= psize;
		p += psize;
	}
	if (EVP_DigestFinal_ex(&ctx, digest->out, &digest->outl) != 1)
		crypto_error();
	if (EVP_MD_CTX_cleanup(&ctx) != 1)
		crypto_error();

	if (verbose) {
		for (i = 0; i < digest->outl; i++)
			printf("%02x", digest->out[i]);
		printf("\n");
	}

	return 0;
}

int
do_hmac(struct digest_data *hmac, unsigned char *key, int size)
{
	EVP_MD_CTX ctx;
	EVP_PKEY *pkey;
	const EVP_MD *type;
	int i;
	int psize;
	int rem;
	unsigned char *p;

	if (verbose)
		printf("hmac(%s) = ", DEFAULT_DIGEST);

	arc4random_buf(hmac->out, sizeof(hmac->out));
	hmac->outl = 0;

	EVP_MD_CTX_init(&ctx);
	type = EVP_get_digestbyname(DEFAULT_DIGEST);
	assert(type != NULL);
	pkey = EVP_PKEY_new_mac_key(EVP_PKEY_HMAC, NULL, key, size);
	if (pkey == NULL)
		crypto_error();
	if (EVP_DigestSignInit(&ctx, NULL, type, NULL, pkey) != 1)
		crypto_error();
	p = hmac->in;
	rem = hmac->inl;
	while (rem > 0) {
		psize = rem > BUF_SIZE ? BUF_SIZE : rem;
		if (EVP_DigestSignUpdate(&ctx, p, psize) != 1)
			crypto_error();
		rem -= psize;
		p += psize;
	}
	if (EVP_DigestSignFinal(&ctx, hmac->out, (size_t *)&hmac->outl) != 1)
		crypto_error();
	EVP_PKEY_free(pkey);
	if (EVP_MD_CTX_cleanup(&ctx) != 1)
		crypto_error();

	if (verbose) {
		for (i = 0; i < hmac->outl; i++)
			printf("%02x", hmac->out[i]);
		printf("\n");
	}

	return 0;
}

void
kdf(uint8_t *salt, size_t saltlen, int rounds, int allowstdin, int confirm,
    uint8_t *key, size_t keylen)
{
	char pass[1024];
	int rppflags = RPP_ECHO_OFF;

	if (rounds == 0) {
		memset(key, 0, keylen);
		return;
	}

	if (allowstdin && !isatty(STDIN_FILENO))
		rppflags |= RPP_STDIN;
	if (!readpassphrase("passphrase: ", pass, sizeof(pass), rppflags))
		errx(1, "unable to read passphrase");
	if (strlen(pass) == 0)
		errx(1, "please provide a password");
	if (confirm && !(rppflags & RPP_STDIN)) {
		char pass2[1024];
		if (!readpassphrase("confirm passphrase: ", pass2,
		    sizeof(pass2), rppflags))
			errx(1, "unable to read passphrase");
		if (strcmp(pass, pass2) != 0)
			errx(1, "passwords don't match");
		explicit_bzero(pass2, sizeof(pass2));
	}
	if (bcrypt_pbkdf(pass, strlen(pass), salt, saltlen, key,
	    keylen, rounds) == -1)
		errx(1, "bcrypt pbkdf");
	explicit_bzero(pass, sizeof(pass));
}

int
regress(void)
{
	struct cipher_data cipher;
	struct digest_data digest1;
	struct digest_data digest2;
	struct digest_data hmac1;
	struct digest_data hmac2;
	unsigned char key[EVP_MAX_KEY_LENGTH];
	unsigned char iv[EVP_MAX_IV_LENGTH];
	unsigned char sign[EVP_MAX_KEY_LENGTH];

	arc4random_buf(&key, sizeof(key));
	arc4random_buf(&iv, sizeof(iv));
	arc4random_buf(&sign, sizeof(sign));

	memset(&cipher, 0, sizeof(cipher));
	cipher.key = key;
	cipher.iv = iv;
	cipher.inl = REGRESS_DATA_SIZE;
	if ((cipher.in = malloc(cipher.inl)) == NULL)
		err(1, "malloc");

	arc4random_buf(cipher.in, cipher.inl);

	/* digest */
	digest1.in = cipher.in;
	digest1.inl = cipher.inl;
	do_digest(&digest1);

	/* hmac */
	hmac1.in = cipher.in;
	hmac1.inl = cipher.inl;
	do_hmac(&hmac1, sign, sizeof(sign));

	/* encrypt */
	cipher.enc = 1;
	do_cipher(&cipher);

	/* decrypt */
	free(cipher.in);
	cipher.in = cipher.out;
	cipher.inl = cipher.outl;
	cipher.out = NULL;
	cipher.outl = 0;
	cipher.enc = 0;
	do_cipher(&cipher);

	free(cipher.in);

	/* digest */
	digest2.in = cipher.out;
	digest2.inl = cipher.outl;
	do_digest(&digest2);

	/* hmac */
	hmac2.in = cipher.out;
	hmac2.inl = cipher.outl;
	do_hmac(&hmac2, sign, sizeof(sign));

	free(cipher.out);

	if (memcmp(digest1.out, digest2.out, sizeof(digest1.out)) != 0)
		warnx("digest regression fail");
	if (memcmp(hmac1.out, hmac2.out, sizeof(hmac1.out)) != 0)
		warnx("hmac regression fail");

	return 0;
}

static int
add_cipher_data(struct cipher_data *cipher, void *buf, size_t size)
{
	unsigned char *p;

	cipher->outl += size;
	if ((p = realloc(cipher->out, cipher->outl)) == NULL)
		err(1, "realloc");
	cipher->out = p;
	p += cipher->outl - size;
	memcpy(p, buf, size);

	return cipher->outl;
}

static void
crypto_error(void)
{
	unsigned long error;

	error = ERR_get_error();
	errx(1, "%s", ERR_error_string(error, NULL));
}
